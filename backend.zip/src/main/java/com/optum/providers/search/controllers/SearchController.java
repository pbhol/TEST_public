package com.optum.providers.search.controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.optum.providers.search.models.Provider;
import com.optum.providers.search.services.SearchService;


@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class SearchController {
 
    @Autowired
    SearchService searchService;

    
    @GetMapping(value="/getListProviders",produces=MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getProvideList(@RequestParam(value="searchKey") String search){
    	
    	if(search==null ||search.isEmpty() ) {
    		return new ResponseEntity<>("Search String Should not be empty", HttpStatus.BAD_REQUEST);
    	}
    	
    	Collection<Provider> data=searchService.getProviders(search);
		return new ResponseEntity<>(data, HttpStatus.OK);
    
    }
    
}
