package com.optum.providers.search.services;

import java.util.Collection;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import static java.util.stream.Collectors.toList;

import com.optum.providers.search.models.Provider;
import com.optum.providers.search.repository.SearchRepository;

@Service
public class SearchServiceImpl implements SearchService{
    
    @Autowired
    SearchRepository searchRepository;
    
    @Override
    public Collection<Provider> getProviders(String searchText) {
        
        return searchRepository.getProviders().stream().filter(element-> 
        element.getName().contains(searchText)).
        		collect(toList());
    }
}
