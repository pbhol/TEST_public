import axios from "axios";

const baseUrl = "http://localhost:8081";

export const searchProviders = async (
  searchString,
  offset = 1,
  limit = 10,
  sortBy = "name"
) => {
  const body = { name: searchString };
  const url = `${baseUrl}/getListProviders?searchKey=${searchString}&sortBy=${sortBy}`;
  const { data } = await axios.get(url, body);
  return data;
};
