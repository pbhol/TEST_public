import React, { useState } from "react";
import { searchProviders } from "../services";


const Serach = () => {
    const [serachKey,setSerachkey]=useState("");
    const [dataList,setDataList]=useState("");

    const fetchListData=async (serachKey)=>{
      const data= await searchProviders(serachKey);
      setDataList(data);
    };
    

    //console.log(serachKey);
    return (
        <>
        <div style={{margin: "3%"}}>
            <input  type="text" style={{width: "80%"}} value={serachKey} onChange={(event)=>setSerachkey(event.target.value)}></input>
            <button onClick={()=>fetchListData(serachKey)}>  Serach </button>
        </div>

        <Card listData={dataList}/>
        </>
    );
}

const Card = (props) => {
    console.log(props);

    console.log("backend", props);


    return (
        <>
        
                <div style={{ margin: "3%" }}>
 
                    <span style={{ margin: "2%" }} >Name : {props?.listData[0].name}</span>
                    <span  >providerType : {props?.listData[0].providerType}</span>

                </div>
    </>
    );
}

export default Serach;


