import React from "react";
import Header from "./Header";
import Serach from "./Serach";

const App = () => {
  return (
    <>
  <Header />
  <Serach/>
  </>
  )
  ;
};

export default App;
